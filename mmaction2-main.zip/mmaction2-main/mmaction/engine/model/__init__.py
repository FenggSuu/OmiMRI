# Copyright (c) OpenMMLab. All rights reserved.
from .weight_init import ConvBranchInit

__all__ = ['ConvBranchInit']
